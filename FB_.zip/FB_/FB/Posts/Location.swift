//
//  Location.swift
//  FB
//
//  Created by Panagiotis  Kompotis  on 09/01/2018.
//  Copyright © 2018 Panagiotis  Kompotis. All rights reserved.
//

import UIKit

class Location : NSObject{
    var city:String?
    var state:String?
}
