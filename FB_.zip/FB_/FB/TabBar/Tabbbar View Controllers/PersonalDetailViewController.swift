//
//  PersonalDetailViewController.swift
//  FB
//
//  Created by Panagiotis  Kompotis  on 04/01/2018.
//  Copyright © 2018 Panagiotis  Kompotis. All rights reserved.
//

import UIKit

class PersonalDetailViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        self.title = "Me"
    }
}
